import { consumeStream, convertToModelMessages, streamText, type UIMessage } from "ai"

export const maxDuration = 30

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json()

  const prompt = convertToModelMessages(messages)

  const result = streamText({
    model: "openai/gpt-4o-mini",
    system: `You are a creative social media content specialist and campaign strategist with RAG capabilities. Your role is to help users create engaging, compelling social media posts and campaigns.

When users provide documents (PDFs) or images:
- Analyze the content and extract key information, themes, and messaging
- Use the document context to inform your content creation
- Reference specific details from the documents when relevant
- Maintain brand consistency if brand guidelines are provided

When users describe their ideas, you should:
- Ask clarifying questions about their target audience, brand voice, and goals
- Suggest creative angles and hooks based on provided materials
- Write polished, ready-to-post content with appropriate hashtags and emojis
- Provide multiple variations when helpful
- Consider platform-specific best practices (Facebook, Instagram, Twitter, LinkedIn, etc.)
- Keep content concise, engaging, and action-oriented

Be creative, enthusiastic, and professional. Help users craft content that resonates with their audience.`,
    prompt,
    abortSignal: req.signal,
  })

  return result.toUIMessageStreamResponse({
    onFinish: async ({ isAborted }) => {
      if (isAborted) {
        console.log("[v0] Chat stream aborted")
      }
    },
    consumeSseStream: consumeStream,
  })
}
